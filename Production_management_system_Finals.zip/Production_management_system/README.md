# Smart_Computer_class_management_system
  Happy to see you here.This is a small mini project.Let me explain how i have tought the problem and how i have resolverd it.
  Imagin a small computer class with 100 students there is only one sir and mam runing the computer class.
  Sometimes they will forgot to update the fees given buy the students.
  For the above problem i have developed a small software with the following things.
  Frontend : Javafx,Css
  Backend  : Java
  DataBae  : Mysql
