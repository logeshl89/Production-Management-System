create database production_management_system;
use production_management_system;
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Store Management', 'Production Management') NOT NULL
);


INSERT INTO users (username, password, role)
VALUES 
('store_admin', 'storepassword123', 'Store Management'),
('production_admin', 'productionpassword123', 'Production Management');


CREATE TABLE vendors (
    vendor_id INT AUTO_INCREMENT PRIMARY KEY,
    vendor_name VARCHAR(100) NOT NULL,
    contact_number VARCHAR(15),
    email VARCHAR(100),
    address TEXT
);


INSERT INTO vendors (vendor_name, contact_number, email, address)
VALUES 
('Vendor A', '1234567890', 'vendorA@example.com', '1234 Market St, City A'),
('Vendor B', '0987654321', 'vendorB@example.com', '5678 Industrial Rd, City B'),
('Vendor C', '5555555555', 'vendorC@example.com', '9101 Elm St, City C');


CREATE TABLE items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    price int NOT NULL,
    vendor_name varchar(50),
    ProductNumber int 
);
INSERT INTO items (item_name, quantity, price, vendor_name, ProductNumber)
VALUES 
    ('Item A', 100, 150, 'Vendor 1', 101),
    ('Item B', 200, 300, 'Vendor 2', 102),
    ('Item C', 150, 250, 'Vendor 3', 103),
    ('Item D', 50, 400, 'Vendor 4', 104),
    ('Item E', 75, 100, 'Vendor 1', 105);


describe items;
CREATE TABLE store_management (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    transaction_type ENUM('IN', 'OUT') NOT NULL,
    quantity INT NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);
describe items;
select * from store_management;
drop table production_reports;
CREATE TABLE production_reports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    report_date DATE NOT NULL,
    machine_number INT NOT NULL,
    fabricator_name VARCHAR(100) NOT NULL,
    project_name VARCHAR(100),
    operation_sequence ENUM('Sheet Cutting & Bending', 'Setting & Welding', 'Grinding', 'Buffing', 'Testing', 'Cleaning & Packing') NOT NULL,
    planned_qty INT,
    actual_qty INT,
    rejected_qty INT,
    progress VARCHAR(50)
);




SELECT transaction_id, product_name, price, quantity
FROM sales;


CREATE TABLE operations (
    operation_id INT AUTO_INCREMENT PRIMARY KEY,
    machine_number INT NOT NULL,
    fabricator_name VARCHAR(100) NOT NULL,
    operation_sequence ENUM('Sheet Cutting & Bending', 'Setting & Welding', 'Grinding', 'Buffing', 'Testing', 'Cleaning & Packing') NOT NULL
);



-- Insert demo data into the items table
INSERT INTO items (item_name, quantity, reorder_level, vendor_id)
VALUES 
('Steel Sheets', 100, 20, 1),
('Welding Rods', 50, 10, 2),
('Grinding Discs', 75, 15, 3);

-- Insert demo data into the store_management table
INSERT INTO store_management (item_id, transaction_type, quantity)
VALUES 
(1, 'IN', 50),
(2, 'OUT', 10),
(3, 'IN', 20),
(1, 'OUT', 5);

-- Insert demo data into the production_reports table
INSERT INTO production_reports (report_date, machine_number, fabricator_name, project_name, operation_sequence, planned_qty, actual_qty, rejected_qty, progress)
VALUES 
('2024-09-01', 101, 'Fabricator A', 'Project Alpha', 'Sheet Cutting & Bending', 50, 48, 2, '96%'),
('2024-09-01', 102, 'Fabricator B', 'Project Beta', 'Setting & Welding', 40, 40, 0, '100%'),
('2024-09-02', 103, 'Fabricator C', 'Project Gamma', 'Grinding', 30, 28, 2, '93%');

-- Insert demo data into the users table
INSERT INTO users (username, password, role)
VALUES 
('store_admin', 'storepassword123', 'Store Management'),
('production_admin', 'productionpassword123', 'Production Management');

-- Insert demo data into the operations table
INSERT INTO operations (machine_number, fabricator_name, operation_sequence)
VALUES 
(101, 'Fabricator A', 'Sheet Cutting & Bending'),
(102, 'Fabricator B', 'Setting & Welding'),
(103, 'Fabricator C', 'Grinding'),
(101, 'Fabricator A', 'Buffing'),
(102, 'Fabricator B', 'Testing');



CREATE TABLE sales_transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO sales_transactions (product_id, quantity, price, transaction_date) VALUES
(1, 10, 29.99, '2024-09-01 10:00:00'),
(2, 5, 49.99, '2024-09-02 11:30:00'),
(3, 7, 19.99, '2024-09-03 14:45:00'),
(4, 2, 99.99, '2024-09-04 09:15:00'),
(5, 8, 15.99, '2024-09-05 16:00:00');

INSERT INTO users (username, password, role)
VALUES 
('admin', 'admin', 'Store Management');

DESCRIBE sales_transactions;
ALTER TABLE sales_transactions
ADD COLUMN product_name VARCHAR(255);


CREATE TABLE sales (
    transaction_id INT PRIMARY KEY,
    product_name VARCHAR(255),
    price DECIMAL(10, 2),
    quantity INT,
    sale_category VARCHAR(255),
    sales_amount DECIMAL(10, 2)
);


-- Insert dummy data into the products table
INSERT INTO products (product_id, product_name, category, price, stock_quantity) VALUES
(1, 'Laptop', 'Electronics', 1200.00, 50),
(2, 'Smartphone', 'Electronics', 800.00, 100),
(3, 'Headphones', 'Accessories', 150.00, 200),
(4, 'Keyboard', 'Accessories', 50.00, 150),
(5, 'Desk Chair', 'Furniture', 200.00, 30),
(6, 'Desk Lamp', 'Furniture', 75.00, 40),
(7, 'Printer', 'Electronics', 300.00, 20),
(8, 'Monitor', 'Electronics', 350.00, 25);





INSERT INTO sales (transaction_id, product_name, price, quantity, sale_category)
VALUES (1, 'Product A', 29.99, 100, 'Electronics');

INSERT INTO sales (transaction_id, product_name, price, quantity, sale_category)
VALUES 
(2, 'Product B', 15.99, 200, 'Clothing'),
(3, 'Product C', 45.50, 150, 'Home Goods'),
(4, 'Product D', 19.99, 120, 'Electronics');
select * from vendors;
describe vendors;

drop table vendors;
CREATE TABLE vendors (
    vendor_id INT AUTO_INCREMENT PRIMARY KEY,
    vendor_name VARCHAR(100) NOT NULL,
    vendor_type VARCHAR(50),
    email VARCHAR(100),
    address VARCHAR(255),
    contact_info VARCHAR(50)
);

ALTER TABLE items
DROP FOREIGN KEY items_ibfk_1;
-- Insert demo data into the vendors table
select * from items;
describe vendors;
INSERT INTO vendors (vendor_id, vendor_name, vendor_type, email, address, contact_info) 
VALUES 
(1, 'Tech Solutions Inc.', 'Technology', 'contact@techsolutions.com', '123 Tech Lane, Silicon Valley, CA', '123-456-7890'),
(2, 'Green Foods Ltd.', 'Food', 'info@greenfoods.com', '456 Organic St, Greenfield, WI', '987-654-3210'),
(3, 'Auto Parts Co.', 'Automotive', 'support@autoparts.com', '789 Car Drive, Detroit, MI', '456-789-1230'),
(4, 'Furniture World', 'Furniture', 'sales@furnitureworld.com', '321 Home Ave, New York, NY', '654-321-0987'),
(5, 'Book Haven', 'Books', 'info@bookhaven.com', '654 Read Rd, Boston, MA', '321-654-9870');


use 
SHOW TABLES LIKE 'specializations';
CREATE TABLE specializations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    specialization_name VARCHAR(255) NOT NULL,
    description TEXToperations
);
INSERT INTO specializations (specialization_name, description) 
VALUES
('Automation', 'Focus on automating production processes to increase efficiency and reduce manual labor.'),
('Quality Control', 'Ensuring the production meets quality standards at every stage.'),
('Supply Chain Management', 'Managing the supply chain to ensure timely procurement of raw materials and delivery of finished goods.'),
('Manufacturing Engineering', 'Developing and improving manufacturing processes and equipment.'),
('Production Planning', 'Planning and scheduling production to meet demand efficiently.'),
('Inventory Management', 'Managing inventory to avoid shortages and overstocking.'),
('Lean Manufacturing', 'Applying lean principles to minimize waste and improve efficiency.'),
('Safety Management', 'Ensuring that all production processes are safe and comply with regulations.');


SELECT * FROM production_management_system.store_management;

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    price DECIMAL(10, 2),
    stock_quantity INT
);
CREATE TABLE operators (
    operator_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(255),
    phone_number VARCHAR(15),
    email VARCHAR(100),
    hire_date DATE,
    status VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
drop table operators;
CREATE TABLE operators (
    operator_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL, -- Added username column
    password_operator VARCHAR(255) NOT NULL, -- Added password_operator column
    phone_number VARCHAR(15) NOT NULL,
    gender VARCHAR(10),  -- Gender field
    specialization VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
select * from operators;
select * from items;

describe items;

ALTER TABLE items
DROP  vendor_id;
alter table items add column vendor_id int not null;





CREATE TABLE Fabricators (
    fabricator_id INT AUTO_INCREMENT PRIMARY KEY,
    fabricator_name VARCHAR(255) NOT NULL
);

CREATE TABLE Machines (
    machine_id INT AUTO_INCREMENT PRIMARY KEY,
    machine_number VARCHAR(50) NOT NULL,
    fabricator_id INT,
    FOREIGN KEY (fabricator_id) REFERENCES Fabricators(fabricator_id)
);

CREATE TABLE Projects (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    project_name VARCHAR(255) NOT NULL
);

drop table ProductionReports ;
CREATE TABLE ProductionReports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    machine_id INT,
    project_id INT,
    product_name VARCHAR(255),
    operation_sequence INT,
    planned_qty INT,
    actual_qty INT,
    rejected_qty INT,
    progress VARCHAR(255),
    machine_id_pr int ,
    project_id_pr int 
);


-- Insert demo data into Fabricators
INSERT INTO Fabricators (fabricator_name) 
VALUES ('John Doe'), ('Jane Smith'), ('Bob Johnson');

-- Insert demo data into Machines
INSERT INTO Machines (machine_number, fabricator_id) 
VALUES ('M-100', 1), ('M-101', 2), ('M-102', 3);

-- Insert demo data into Projects
INSERT INTO Projects (project_name) 
VALUES ('Project Alpha'), ('Project Beta'), ('Project Gamma');

-- Insert demo data into ProductionReports
INSERT INTO ProductionReports (machine_id, project_id, product_name, operation_sequence, planned_qty, actual_qty, rejected_qty, progress)
VALUES 
(1, 1, 'Product A', 1, 100, 95, 5, 'In Progress'),
(2, 2, 'Product B', 2, 200, 180, 10, 'Completed'),
(3, 3, 'Product C', 3, 150, 140, 8, 'Testing');
select * from projects;

INSERT INTO ProductionReports (machine_id, project_id, product_name, operation_sequence, planned_qty, actual_qty, rejected_qty, progress, machine_id_pr, project_id_pr) VALUES
(1, 1, 'Product A', 1, 100, 95, 5, 'In Progress', 1, 1),
(1, 1, 'Product B', 2, 150, 145, 5, 'Completed', 1, 1),
(2, 2, 'Product C', 3, 200, 190, 10, 'Completed', 2, 2),
(2, 2, 'Product D', 4, 250, 240, 10, 'In Progress', 2, 2),
(3, 3, 'Product E', 5, 300, 290, 10, 'Testing', 3, 3),
(3, 3, 'Product F', 6, 350, 340, 10, 'Completed', 3, 3),
(4, 4, 'Product G', 1, 400, 395, 5, 'In Progress', 4, 4),
(4, 4, 'Product H', 2, 450, 445, 5, 'Completed', 4, 4),
(5, 5, 'Product I', 3, 500, 490, 10, 'Completed', 5, 5),
(5, 5, 'Product J', 4, 550, 540, 10, 'Testing', 5, 5),
(6, 6, 'Product K', 5, 600, 590, 10, 'Completed', 6, 6),
(6, 6, 'Product L', 6, 650, 640, 10, 'In Progress', 6, 6),
(7, 7, 'Product M', 1, 700, 690, 10, 'Completed', 7, 7),
(7, 7, 'Product N', 2, 750, 740, 10, 'In Progress', 7, 7),
(8, 8, 'Product O', 3, 800, 790, 10, 'Testing', 8, 8),
(8, 8, 'Product P', 4, 850, 840, 10, 'Completed', 8, 8),
(9, 9, 'Product Q', 5, 900, 890, 10, 'In Progress', 9, 9),
(9, 9, 'Product R', 6, 950, 940, 10, 'Completed', 9, 9),
(10, 10, 'Product S', 1, 1000, 990, 10, 'Testing', 10, 10),
(10, 10, 'Product T', 2, 1050, 1040, 10, 'In Progress', 10, 10),
(11, 11, 'Product U', 3, 1100, 1090, 10, 'Completed', 11, 11);

select * from vendors;
describe vendors;
select * from items;
describe items;
update  items set vendor_id=1 where vendor_id=0;
select * from users;
select * from operators;
describe operators;
drop table operators;
CREATE TABLE operators (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    specialization VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL
);

drop table operators;

CREATE TABLE operator (
    operator_id INT AUTO_INCREMENT PRIMARY KEY,
    operator_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    gender VARCHAR(10),
    specialization VARCHAR(100),
    email VARCHAR(100)
);

-- Inserting demo data
INSERT INTO operator (operator_name, phone_number, gender, specialization, email) 
VALUES 
    ('John Doe', '1234567890', 'Male', 'Welding', 'john@example.com'),
    ('Jane Smith', '0987654321', 'Female', 'Grinding', 'jane@example.com'),
    ('Mike Brown', '5556667777', 'Male', 'Setting', 'mike@example.com'),
    ('Emily Davis', '1112223333', 'Female', 'Cleaning', 'emily@example.com');
INSERT INTO operators (name, phone_number, gender, username, email)
VALUES 
('John Doe', '9876543210', 'Male', 'johndoe', 'johndoe@example.com'),
('Jane Smith', '9123456789', 'Female', 'janesmith', 'janesmith@example.com'),
('Michael Brown', '9988776655', 'Male', 'michaelbrown', 'michaelbrown@example.com'),
('Emily Johnson', '9554433221', 'Female', 'emilyjohnson', 'emilyjohnson@example.com'),
('David Wilson', '9871122334', 'Male', 'davidwilson', 'davidwilson@example.com');
truncate table operator;
alter table items add column ProductNumber int;
select * from items;	
select * from users;
describe items;


ALTER TABLE items RENAME COLUMN vendor_id TO vendor_name;
ALTER TABLE items MODIFY vendor_name VARCHAR(50);

select * from Projects;
select * from ProductionReports;

CREATE TABLE Fabricators (
    fabricator_id INT AUTO_INCREMENT PRIMARY KEY,
    fabricator_name VARCHAR(255) NOT NULL
);

CREATE TABLE Machines (
    machine_id INT AUTO_INCREMENT PRIMARY KEY,
    machine_number VARCHAR(50) NOT NULL,
    fabricator_id INT,
    FOREIGN KEY (fabricator_id) REFERENCES Fabricators(fabricator_id)
);

CREATE TABLE Projects (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    project_name VARCHAR(255) NOT NULL
);
CREATE TABLE ProductionReports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    machine_id INT,
    project_id INT,
    product_name VARCHAR(255),
    operation_sequence INT,
    planned_qty INT,
    actual_qty INT,
    rejected_qty INT,
    progress VARCHAR(255),
    machine_id_pr int ,
    project_id_pr int 
);
INSERT INTO Fabricators (fabricator_name) VALUES
('Fabricator A'),
('Fabricator B'),
('Fabricator C');
INSERT INTO Machines (machine_number, fabricator_id) VALUES
('Machine 101', 1),
('Machine 102', 2),
('Machine 103', 3);

INSERT INTO Projects (project_name, start_date) VALUES
('Project Alpha', '2024-01-15'),
('Project Beta', '2024-03-22'),
('Project Gamma', '2024-06-10');
INSERT INTO ProductionReports (machine_id, project_id, product_name, operation_sequence, planned_qty, actual_qty, rejected_qty, progress, start_date) VALUES
(101, 1, 'Product A', 1, 100, 95, 5, 'Completed', '2024-01-15'),
(102, 2, 'Product B', 2, 150, 145, 5, 'In Progress', '2024-03-22'),
(103, 3, 'Product C', 3, 200, 190, 10, 'Not Started', '2024-06-10');
select * from projects;
select * from fabricators;
select * from items;
describe items;

INSERT INTO items (item_name, quantity, price, vendor_name, ProductNumber) VALUES
('Item A', 100, 10.99, 'Vendor X', '2001'),
('Item B', 200, 20.49, 'Vendor Y', '2002'),
('Item C', 150, 15.75, 'Vendor Z', '2003'),
('Item D', 250, 25.00, 'Vendor X', '2004');
select * from items;

INSERT INTO store_management (item_id, transaction_type, quantity, transaction_date) VALUES
(1, 'IN', 50, '2024-09-01 10:00:00'),
(2, 'OUT', 30, '2024-09-01 11:00:00'),
(1, 'IN', 20, '2024-09-02 09:00:00'),
(3, 'OUT', 15, '2024-09-02 10:30:00'),
(2, 'IN', 40, '2024-09-03 14:00:00'),
(4, 'OUT', 10, '2024-09-03 15:45:00'),
(3, 'IN', 25, '2024-09-04 08:30:00'),
(1, 'OUT', 45, '2024-09-04 12:00:00'),
(4, 'IN', 35, '2024-09-05 13:00:00'),
(2, 'OUT', 20, '2024-09-05 16:00:00');
SELECT CONSTRAINT_NAME 
FROM information_schema.KEY_COLUMN_USAGE 
WHERE TABLE_NAME = 'store_management' 
  AND TABLE_SCHEMA = 'production_management_system' 
  AND REFERENCED_TABLE_NAME = 'items';
SELECT CONSTRAINT_NAME 
FROM information_schema.KEY_COLUMN_USAGE 
WHERE TABLE_NAME = 'store_management' 
  AND TABLE_SCHEMA = 'production_management_system' 
  AND (REFERENCED_TABLE_NAME IS NULL OR REFERENCED_TABLE_NAME != 'items');
ALTER TABLE store_management 
DROP FOREIGN KEY store_management_ibfk_1;
describe operator;
select * from users;
select * from items;
describe store_management;
ALTER TABLE ProductionReports MODIFY operation_sequence VARCHAR(255);
select * from ProductionReports;
describe ProductionReports;
CREATE TABLE items (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    vendor_name VARCHAR(255),
    ProductNumber INT
);

CREATE TABLE customer_info (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(15) NOT NULL,
    product_price DECIMAL(10, 2) NOT NULL,
    initial_payment DECIMAL(10, 2) NOT NULL,
    complaint VARCHAR(255),
    date_of_entry DATE,
    status VARCHAR(10)
);
INSERT INTO customer_info (customer_name, customer_phone, product_price, initial_payment, complaint, date_of_entry, status)
VALUES
('John Doe', '9876543210', 1500.50, 500.00, 'Product arrived damaged', '2024-09-01', 'In'),
('Jane Smith', '9123456789', 3200.75, 1000.00, 'Delayed delivery', '2024-09-05', 'Out'),
('Michael Johnson', '9898989898', 5000.00, 3000.00, 'Warranty request', '2024-09-10', 'In'),
('Emily Davis', '9123123123', 2200.40, 1200.40, 'Color mismatch', '2024-09-12', 'Out'),
('Chris Evans', '9345678901', 850.25, 850.25, 'No complaint', '2024-09-15', 'In');
select * from users;
ALTER TABLE customer_info
MODIFY status VARCHAR(10) DEFAULT 'In';
CREATE TABLE DailyProductionReport (
    report_id INT PRIMARY KEY AUTO_INCREMENT,
    machine_number VARCHAR(50),
    fabricator_name VARCHAR(100),
    project_name VARCHAR(100),
    product_name VARCHAR(100),
    operation_sequence VARCHAR(255),
    planned_qty INT,
    actual_qty INT,
    rejected_qty INT,
    progress VARCHAR(50),
    report_date DATE,
    start_time VARCHAR(255),
    end_time VARCHAR(255)
);
describe DailyProductionReport;
INSERT INTO DailyProductionReport (
    machine_number, fabricator_name, project_name, product_name, operation_sequence, 
    planned_qty, actual_qty, rejected_qty, progress, report_date, start_time, end_time
) VALUES
('M001', 'John Doe', 'Project Alpha', 'Product A', 'Sheet Cutting & Bending', 100, 95, 5, '95%', '2024-09-16', '2024-09-16 08:00:00', '2024-09-16 16:00:00'),
('M002', 'Jane Smith', 'Project Beta', 'Product B', 'Setting & Welding', 200, 180, 20, '90%', '2024-09-16', '2024-09-16 09:00:00', '2024-09-16 17:00:00'),
('M003', 'Michael Johnson', 'Project Gamma', 'Product C', 'Grinding', 150, 140, 10, '93%', '2024-09-16', '2024-09-16 07:30:00', '2024-09-16 15:30:00'),
('M004', 'Emily Davis', 'Project Delta', 'Product D', 'Buffing', 120, 118, 2, '98%', '2024-09-16', '2024-09-16 08:15:00', '2024-09-16 16:15:00'),
('M005', 'David Wilson', 'Project Epsilon', 'Product E', 'Testing', 250, 240, 10, '96%', '2024-09-16', '2024-09-16 09:00:00', '2024-09-16 17:30:00'),
('M006', 'Sarah Brown', 'Project Zeta', 'Product F', 'Cleaning & Packing', 300, 290, 10, '97%', '2024-09-16', '2024-09-16 08:00:00', '2024-09-16 16:30:00'),
('M007', 'Chris Green', 'Project Eta', 'Product G', 'Sheet Cutting & Bending', 400, 380, 20, '95%', '2024-09-16', '2024-09-16 08:45:00', '2024-09-16 17:15:00'),
('M008', 'Rachel White', 'Project Theta', 'Product H', 'Setting & Welding', 350, 345, 5, '99%', '2024-09-16', '2024-09-16 09:30:00', '2024-09-16 17:45:00'),
('56', 'sdfsd', '566', 'fdgdf', 45, 455, 4455, 4, 'Completed', '2024-09-17', '2024-09-17 10:00:00', '2024-09-17 14:00:00');

select * from users;
drop table sales;