package com.example.Production_management_system;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;



public class ProductionReportController {

	@FXML
	private DatePicker reportDatePicker;
	@FXML
	private TextField CustomerPhoneNumber;

	@FXML
	private ComboBox<String> statusFilter;

	@FXML
	private TableView<Customer> customerTable;

	@FXML
	private TableColumn<Customer, String> idColumn;
	@FXML
	private TableColumn<Customer, String> nameColumn;
	@FXML
	private TableColumn<Customer, String> phoneColumn;
	@FXML
	private TableColumn<Customer, String> priceColumn;
	@FXML
	private TableColumn<Customer, String> paymentColumn;
	@FXML
	private TableColumn<Customer, String> complaintColumn;
	@FXML
	private TableColumn<Customer, LocalDate> dateColumn;
	@FXML
	private TableColumn<Customer, String> statusColumn;

	private ObservableList<Customer> customerList = FXCollections.observableArrayList();
	private FilteredList<Customer> filteredCustomerList;

	@FXML
	public void initialize() {
		// Initialize table columns
		idColumn.setCellValueFactory(cellData -> cellData.getValue().customerIdProperty().asString());
		nameColumn.setCellValueFactory(cellData -> cellData.getValue().customerNameProperty());
		phoneColumn.setCellValueFactory(cellData -> cellData.getValue().customerPhoneProperty());
		priceColumn.setCellValueFactory(cellData -> cellData.getValue().productPriceProperty().asString());
		paymentColumn.setCellValueFactory(cellData -> cellData.getValue().initialPaymentProperty().asString());
		complaintColumn.setCellValueFactory(cellData -> cellData.getValue().complaintProperty());
		dateColumn.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().getDateOfEntry()));
		statusColumn.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

		// Load customer data from the database
		loadCustomerData();

		// Create a filtered list to allow filtering
		filteredCustomerList = new FilteredList<>(customerList, p -> true);
		customerTable.setItems(filteredCustomerList);

		// Add listener for phone number search
		CustomerPhoneNumber.textProperty().addListener((observable, oldValue, newValue) -> {
			filterCustomers();
		});

		// Add listener for status filter
		statusFilter.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			filterCustomers();
		});

		statusColumn.setCellFactory(column -> new TableCell<Customer, String>() {
			@Override
			protected void updateItem(String status, boolean empty) {
				super.updateItem(status, empty);

				if (status == null || empty) {
					setText(null);
					setStyle("");
				} else {
					setText(status);
					if ("In".equals(status)) {
						setStyle("-fx-background-color: red;");
					} else if ("Out".equals(status)) {
						setStyle("-fx-background-color: green;");
					}
				}
			}
		});
	}

	private void filterCustomers() {
		String phoneSearch = CustomerPhoneNumber.getText().toLowerCase();
		String statusSearch = statusFilter.getSelectionModel().getSelectedItem();

		filteredCustomerList.setPredicate(customer -> {
			boolean matchesPhone = customer.getCustomerPhone().toLowerCase().contains(phoneSearch);
			boolean matchesStatus = (statusSearch == null || statusSearch.equals("All") || customer.getStatus().equals(statusSearch));

			return matchesPhone && matchesStatus;
		});
	}

	private void loadCustomerData() {
		customerList.clear();
		String query = "SELECT * FROM customer_info";

		try (
				PreparedStatement preparedStatement = Connector.connection().prepareStatement(query);
				ResultSet resultSet = preparedStatement.executeQuery()) {

			while (resultSet.next()) {
				// Fetch data from the ResultSet
				int customerId = resultSet.getInt("customer_id");
				String customerName = resultSet.getString("customer_name");
				String customerPhone = resultSet.getString("customer_phone");
				double productPrice = resultSet.getDouble("product_price");
				double initialPayment = resultSet.getDouble("initial_payment");
				String complaint = resultSet.getString("complaint");
				String status = resultSet.getString("status");
				LocalDate dateOfEntry = resultSet.getDate("date_of_entry").toLocalDate();

				// Add a new Customer to the customerList
				customerList.add(new Customer(
						customerId,
						customerName,
						customerPhone,
						productPrice,
						initialPayment,
						complaint,
						dateOfEntry,
						status
				));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	@FXML
	private void generateReport() {
		// Get the selected date and status
		LocalDate selectedDate = reportDatePicker.getValue();
		String selectedStatus = statusFilter.getSelectionModel().getSelectedItem();

		// Filter the data based on the selected date and status
		ObservableList<Customer> filteredData = FXCollections.observableArrayList();
		for (Customer customer : customerList) {
			if ((selectedDate == null || customer.getDateOfEntry().equals(selectedDate)) &&
					(selectedStatus == null || selectedStatus.equals("All") || customer.getStatus().equals(selectedStatus))) {
				filteredData.add(customer);
			}
		}

		// Instantiate WordReportGenerator and generate the report
		WordReportGenerator reportGenerator = new WordReportGenerator();
		reportGenerator.generateReport(filteredData);
	}

}
