package com.example.Production_management_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

public class ItemController implements Initializable {

    @FXML
    private TextField ItemName;
    @FXML
    private TextField Quantity;
    @FXML
    private ComboBox<String> VendorComboBox;
    @FXML
    private TextField ProductPrice;

    @FXML
    private TextField ProductNumber;
    private Connection connection;
    private PreparedStatement preparedStatement;
    private Alert alert;

    private Stage stage;
    private Scene scene;

    // Method to validate and add item
    @FXML
    protected void Validator(ActionEvent event) throws SQLException {
        // Check if the fields are properly filled
        if (ItemName.getText().length() > 0 &&
                !Objects.equals(Quantity.getText(), "") &&
                VendorComboBox.getValue() != null ) {


            String insertQuery = "INSERT INTO items (item_name, quantity,vendor_name, price,ProductNumber) VALUES (?, ?, ?, ?,?)";


            try {
                PreparedStatement preparedStatement = Connector.connection().prepareStatement(insertQuery);
                preparedStatement.setString(1, ItemName.getText());
                preparedStatement.setInt(2, Integer.parseInt(Quantity.getText()));
                preparedStatement.setString(3,VendorComboBox.getValue());
                preparedStatement.setInt(4,Integer.parseInt(ProductPrice.getText()));
                preparedStatement.setInt(5,Integer.parseInt(ProductNumber.getText()));
                preparedStatement.executeUpdate();


                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Successful");
                alert.setContentText("Successfully added");
                alert.showAndWait();

                // Clear the input fields
                Clear();
            } catch (SQLException e) {
                e.printStackTrace();
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setContentText("An error occurred while adding the item.");
                alert.showAndWait();
            }
        } else {
            // Show error alert if validation fails
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation Error");
            alert.setHeaderText("Please enter valid data in all fields.");
            alert.showAndWait();
        }
    }

    // Method to clear input fields
    private void Clear() {
        ItemName.clear();
        Quantity.clear();
        VendorComboBox.setValue(null);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            // Populate VendorComboBox from database
            String query = "SELECT Vendor_name FROM production_management_system.vendors;";
            Statement statement = Connector.connection().createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                VendorComboBox.getItems().add(resultSet.getString(1));
            }
            Clear();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    protected void Switch_To_Dashboard(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("DashBoard.fxml")));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void MinimizeButtonClicked(MouseEvent event) {
        ((Stage) ((ImageView) event.getSource()).getScene().getWindow()).setIconified(true);
    }
}
