package com.example.Production_management_system;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Vendor {

	private final IntegerProperty vendorId;
	private final StringProperty vendorName;
	private final StringProperty vendorType;
	private final StringProperty email;
	private final StringProperty address;
	private final StringProperty contactInfo;

	public Vendor(int vendorId, String vendorName, String vendorType, String email, String address, String contactInfo) {
		this.vendorId = new SimpleIntegerProperty(vendorId);
		this.vendorName = new SimpleStringProperty(vendorName);
		this.vendorType = new SimpleStringProperty(vendorType);
		this.email = new SimpleStringProperty(email);
		this.address = new SimpleStringProperty(address);
		this.contactInfo = new SimpleStringProperty(contactInfo);
	}

	// Getters and Setters
	public int getVendorId() {
		return vendorId.get();
	}

	public void setVendorId(int vendorId) {
		this.vendorId.set(vendorId);
	}

	public IntegerProperty vendorIdProperty() {
		return vendorId;
	}

	public String getVendorName() {
		return vendorName.get();
	}

	public void setVendorName(String vendorName) {
		this.vendorName.set(vendorName);
	}

	public StringProperty vendorNameProperty() {
		return vendorName;
	}

	public String getVendorType() {
		return vendorType.get();
	}

	public void setVendorType(String vendorType) {
		this.vendorType.set(vendorType);
	}

	public StringProperty vendorTypeProperty() {
		return vendorType;
	}

	public String getEmail() {
		return email.get();
	}

	public void setEmail(String email) {
		this.email.set(email);
	}

	public StringProperty emailProperty() {
		return email;
	}

	public String getAddress() {
		return address.get();
	}

	public void setAddress(String address) {
		this.address.set(address);
	}

	public StringProperty addressProperty() {
		return address;
	}

	public String getContactInfo() {
		return contactInfo.get();
	}

	public void setContactInfo(String contactInfo) {
		this.contactInfo.set(contactInfo);
	}

	public StringProperty contactInfoProperty() {
		return contactInfo;
	}
}
