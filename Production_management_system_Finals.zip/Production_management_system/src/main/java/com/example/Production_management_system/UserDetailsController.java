package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class UserDetailsController implements Initializable {

	@FXML
	private TableView<User> userTableView;

	@FXML
	private TableColumn<User, String> userIdColumn;

	@FXML
	private TableColumn<User, String> userNameColumn;

	@FXML
	private TableColumn<User, String> userEmailColumn;

	@FXML
	private Button loadUsersButton;

	private ObservableList<User> userList = FXCollections.observableArrayList();

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		userIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
		userNameColumn.setCellValueFactory(new PropertyValueFactory<>("userName"));
		userEmailColumn.setCellValueFactory(new PropertyValueFactory<>("userEmail"));

		// Load users when the controller is initialized
		loadUsersFromDatabase();
	}

	@FXML
	private void loadUsersFromDatabase() {

		try 		 {
			String query = "SELECT * FROM users"; // Assuming table name is 'users'
			Statement statement = Connector.connection().createStatement();
			ResultSet resultSet = statement.executeQuery(query);

			// Clear the userList before adding new data
			userList.clear();

			// Loop through the result set and add data to the userList
			while (resultSet.next()) {
				String userId = resultSet.getString("user_id");
				String userName = resultSet.getString("user_name");
				String userEmail = resultSet.getString("user_email");

				userList.add(new User(userId, userName, userEmail));
			}

			// Set the userList in the TableView
			userTableView.setItems(userList);

		} catch (Exception e) {
			e.printStackTrace(); // Handle any exceptions (such as connection failure)
		}
	}
}
