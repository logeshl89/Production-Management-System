package com.example.Production_management_system;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class ProductionAddition {

    @FXML
    private TextField CustomerPhoneNumber;

    @FXML
    private TextField ProductPrice;

    @FXML
    private TextField InitialPaymentByCustomer;

    @FXML
    private Button CreateButton;

    @FXML
    private TextField CustomerUserName;

    @FXML
    private ComboBox<String> ComplientByCustomer;

    @FXML
    private DatePicker DateOfEnter;

    @FXML
    private void initialize() {
        // Initialize ComboBox options
        ComplientByCustomer.getItems().addAll(
                "Sheet Cutting & Bending",
                "Setting & Welding",
                "Grinding",
                "Buffing",
                "Testing",
                "Cleaning & Packing",
                "Sales" // Added sales option
        );

        // Add action listener to the Create button
        CreateButton.setOnAction(event -> Validator());
    }

    @FXML
    private void Validator() {
        // Get input values
        String name = CustomerUserName.getText();
        String phoneNumber = CustomerPhoneNumber.getText();
        String priceText = ProductPrice.getText();
        String initialPaymentText = InitialPaymentByCustomer.getText();
        String complaint = ComplientByCustomer.getValue();
        LocalDate dateOfEntry = DateOfEnter.getValue();

        // Basic validation
        if (name.isEmpty() || phoneNumber.isEmpty() || priceText.isEmpty() || initialPaymentText.isEmpty() || complaint == null || dateOfEntry == null) {
            showAlert(AlertType.ERROR, "Form Error!", "Please fill all fields.");
            return;
        }

        double productPrice;
        double initialPayment;

        try {
            productPrice = Double.parseDouble(priceText);
            initialPayment = Double.parseDouble(initialPaymentText);
        } catch (NumberFormatException e) {
            showAlert(AlertType.ERROR, "Form Error!", "Please enter valid numbers for Price and Initial Payment.");
            return;
        }

        // Save to database
        String query = "INSERT INTO customer_info (customer_name, customer_phone, product_price, initial_payment, complaint, date_of_entry) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = Connector.connection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, phoneNumber);
            preparedStatement.setDouble(3, productPrice);
            preparedStatement.setDouble(4, initialPayment);
            preparedStatement.setString(5, complaint);
            preparedStatement.setDate(6, java.sql.Date.valueOf(dateOfEntry));
            preparedStatement.executeUpdate();
            showAlert(AlertType.INFORMATION, "Success", "Customer added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Database Error", "Unable to save customer data.");
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
