package com.example.Production_management_system;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;

public class ItemDetails {

	private final StringProperty itemId;
	private final StringProperty itemName;
	private final IntegerProperty quantity;
	private final IntegerProperty price;
	private final StringProperty vendor_name;
	private final IntegerProperty productId;


	public ItemDetails(String itemId, String itemName, int quantity, int price,String vendorname, int productId) {
		this.itemId = new SimpleStringProperty(itemId);
		this.itemName = new SimpleStringProperty(itemName);
		this.quantity = new SimpleIntegerProperty(quantity);
		this.price = new SimpleIntegerProperty(price);
		this.vendor_name =new SimpleStringProperty(vendorname);
		this.productId = new SimpleIntegerProperty(productId); // Use SimpleIntegerProperty for consistency
	}

	public String getItemId() {
		return itemId.get();
	}

	public void setItemId(String itemId) {
		this.itemId.set(itemId);
	}

	public StringProperty itemIdProperty() {
		return itemId;
	}

	public String getItemName() {
		return itemName.get();
	}

	public void setItemName(String itemName) {
		this.itemName.set(itemName);
	}

	public StringProperty itemNameProperty() {
		return itemName;
	}

	public int getQuantity() {
		return quantity.get();
	}

	public void setQuantity(int quantity) {
		this.quantity.set(quantity);
	}

	public IntegerProperty quantityProperty() {
		return quantity;
	}

	public int getPrice() {
		return price.get();
	}

	public void setPrice(int price) {
		this.price.set(price);
	}

	public IntegerProperty priceProperty() {
		return price;
	}



	public StringProperty vendor_nameProperty() {
		return vendor_name;
	}

	public String getVendor_name() {
		return vendor_name.get();
	}

	public void setVendor_name(String vendor_name) {
		this.vendor_name.set(vendor_name);
	}

	public int getProductId() {
		return productId.get();
	}

	public void setProductId(int productId) {
		this.productId.set(productId);
	}

	public IntegerProperty productIdProperty() {
		return productId;
	}
}
