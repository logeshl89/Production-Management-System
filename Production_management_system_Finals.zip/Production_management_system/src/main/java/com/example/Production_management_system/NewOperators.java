package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class NewOperators implements Initializable {

	@FXML
	private TextField NameOfTheOperator;

	@FXML
	private TextField PhoneNumberOfTheOperator;

	@FXML
	private ComboBox<String> Genders;

	@FXML
	private ComboBox<String> Specialization;

	@FXML
	private TextField emailField;

	@FXML
	private Button CreateButton;

	@FXML
	private Button DeleteButton;

	@FXML
	private Button UpdateButton;

	@FXML
	private TableView<Operator> operatorTableView;

	@FXML
	private TableColumn<Operator, Integer> idColumn;

	@FXML
	private TableColumn<Operator, String> specification;

	@FXML
	private TableColumn<Operator, String> nameColumn;

	@FXML
	private TableColumn<Operator, String> phoneColumn;

	@FXML
	private TableColumn<Operator, String> genderColumn;

	@FXML
	private TableColumn<Operator, String> emailColumn;

	private ObservableList<Operator> operatorList = FXCollections.observableArrayList();


	@FXML
	private void loadOperators() throws SQLException {
		operatorList.clear();

		String query = "SELECT * FROM operator";
		try {
			Statement stmt = Connector.connection().createStatement();
			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				Operator operator = new Operator(
						rs.getInt("operator_id"),
						rs.getString("operator_name"),
						rs.getString("phone_number"),
						rs.getString("gender"),
						rs.getString("specialization"),
						rs.getString("email")
				);
				operatorList.add(operator);
			}
			operatorTableView.setItems(operatorList);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void addOperator() throws SQLException {
		Connection conn = Connector.connection();
		String query = "INSERT INTO operator (operator_name, phone_number, gender, specialization, email) VALUES (?, ?, ?, ?, ?)";

		try {
			PreparedStatement stmt = Connector.connection().prepareStatement(query);
			stmt.setString(1, NameOfTheOperator.getText());
			stmt.setString(2, PhoneNumberOfTheOperator.getText());
			stmt.setString(3, Genders.getValue());
			stmt.setString(4, Specialization.getValue());
			stmt.setString(5, emailField.getText());
			stmt.executeUpdate();
			loadOperators();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		NameOfTheOperator.clear();
		PhoneNumberOfTheOperator.clear();
		Genders.setValue("Male");
		emailField.clear();
	}

	private void deleteOperator() throws SQLException {
		Operator selectedOperator = operatorTableView.getSelectionModel().getSelectedItem();

		if (selectedOperator == null) {
			Alert alert = new Alert(Alert.AlertType.WARNING, "Please select an operator to delete.", ButtonType.OK);
			alert.showAndWait();
			return;
		}

		Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION,
				"Are you sure you want to delete this operator?", ButtonType.YES, ButtonType.NO);
		confirmationAlert.showAndWait().ifPresent(response -> {
			if (response == ButtonType.YES) {
				try {
					Connection conn = Connector.connection();
					String query = "DELETE FROM operator WHERE operator_id = ?";
					PreparedStatement stmt = conn.prepareStatement(query);
					stmt.setInt(1, selectedOperator.getId());
					stmt.executeUpdate();
					loadOperators();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void updateOperator() throws SQLException {
		Operator selectedOperator = operatorTableView.getSelectionModel().getSelectedItem();
		if (selectedOperator == null) {
			return;
		}
		String query = "UPDATE operator SET operator_name = ?, phone_number = ?, gender = ?, specialization = ?, email = ? WHERE operator_id = ?";

		try {
			PreparedStatement stmt = Connector.connection().prepareStatement(query);
			stmt.setString(1, NameOfTheOperator.getText());
			stmt.setString(2, PhoneNumberOfTheOperator.getText());
			stmt.setString(3, Genders.getValue());
			stmt.setString(4, Specialization.getValue());
			stmt.setString(5, emailField.getText());
			stmt.setInt(6, selectedOperator.getId());
			stmt.executeUpdate();
			loadOperators();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		Genders.setItems(FXCollections.observableArrayList("Male", "Female"));
		Specialization.setItems(FXCollections.observableArrayList("Manager", "Technician", "Engineer"));

		idColumn.setCellValueFactory(new PropertyValueFactory <>("id"));
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("operatorName"));
		phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
		genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
		emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
		specification.setCellValueFactory(new PropertyValueFactory<>("specialization"));
		try {
			loadOperators();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		operatorTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			if (newValue != null) {
				NameOfTheOperator.setText(newValue.getOperatorName());
				PhoneNumberOfTheOperator.setText(newValue.getPhoneNumber());
				Genders.setValue(newValue.getGender());
				Specialization.setValue(newValue.getSpecialization());
				emailField.setText(newValue.getEmail());
			}
		});

		CreateButton.setOnAction(event -> {
			try {
				addOperator();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		});

		DeleteButton.setOnAction(event -> {
			try {
				deleteOperator();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		});

		UpdateButton.setOnAction(event -> {
			try {
				updateOperator();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		});
	}
}
