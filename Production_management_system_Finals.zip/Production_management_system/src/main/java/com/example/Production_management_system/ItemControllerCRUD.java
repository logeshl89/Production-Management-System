package com.example.Production_management_system;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

public class ItemControllerCRUD implements Initializable {

	@FXML
	private TableView<ItemDetails> itemTableView;
	@FXML
	private TableColumn<ItemDetails, Number> productIdColumn;

	@FXML
	private TableColumn<ItemDetails, String> itemIdColumn;

	@FXML
	private TableColumn<ItemDetails, String> itemNameColumn;

	@FXML
	private TableColumn<ItemDetails, Number> quantityColumn;

	@FXML
	private TableColumn<ItemDetails, Number> productPriceColumn;

	@FXML
	private TableColumn<ItemDetails, String> vendorIdColumn;

	@FXML
	private TextField ItemId;

	@FXML
	private TextField ItemName;

	@FXML
	private TextField Quantity;

	@FXML
	private TextField ProductPrice;

	@FXML
	private ComboBox<String> VendorComboBox;

	@FXML
	private TextField Productid;

	@FXML
	private Button DeleteItemButton;

	@FXML
	private Button UpdateItemButton;


	@FXML
	private Button Back_To_Home;

	@FXML
	private ImageView CloseButton;

	private Parent root;
	private Stage stage;
	private Scene scene;

	private ObservableList<ItemDetails> itemList = FXCollections.observableArrayList();

	@FXML
	void Switch_To_Dashboard(ActionEvent event) throws IOException {
		root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("DashBoard.fxml")));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void handleCRUDOperations(ActionEvent event) {
		try {
			if (event.getSource() == DeleteItemButton) {
				deleteItem();
			} else if (event.getSource() == UpdateItemButton) {
				updateItem();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void deleteItem() throws SQLException {
		try (Connection conn = Connector.connection()) {
			String deleteFromItems = "DELETE FROM items WHERE item_id = ?";
			PreparedStatement ps2 = conn.prepareStatement(deleteFromItems);
			ps2.setInt(1, Integer.parseInt(ItemId.getText()));
			ps2.executeUpdate();
			showAlert(Alert.AlertType.INFORMATION, "Success", "The item has been successfully deleted.");
		} catch (SQLException e) {
			showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete the item.");

			e.printStackTrace();
		}
		loadItemsFromDatabase();
	}

	private void updateItem() throws SQLException {
		String query = "UPDATE items SET item_name = ?, quantity = ?, price = ?, vendor_name = ?, ProductNumber = ? WHERE item_id = ?;";
		try  {
			PreparedStatement preparedStatement = Connector.connection().prepareStatement(query);
			preparedStatement.setString(1, ItemName.getText());
			preparedStatement.setInt(2, Integer.parseInt(Quantity.getText()));
			preparedStatement.setBigDecimal(3, new BigDecimal(ProductPrice.getText()));
			preparedStatement.setString(4, VendorComboBox.getValue());
			preparedStatement.setInt(6, Integer.parseInt(Productid.getText()));
			preparedStatement.setInt(5,Integer.parseInt(ItemId.getText()));
			int rowsUpdated = preparedStatement.executeUpdate();

			if (rowsUpdated > 0) {
				System.out.println("Update successful. " + rowsUpdated + " row(s) updated.");
			} else {
				System.out.println("No rows updated. Check if the item_id exists.");
			}
			loadItemsFromDatabase();
			showAlert(Alert.AlertType.INFORMATION, "Success", "Item successfully updated.");
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} catch (NumberFormatException e) {
			throw new RuntimeException(e);
		}
	}


	private void loadItemsFromDatabase() {
		String query = "SELECT * FROM items";
		try (Connection conn = Connector.connection();
			 Statement statement = conn.createStatement();
			 ResultSet resultSet = statement.executeQuery(query)) {

			itemList.clear();

			while (resultSet.next()) {
				String itemId = resultSet.getString("item_id");
				String itemName = resultSet.getString("item_name");
				int quantity = resultSet.getInt("quantity");
				int price = resultSet.getInt("price");
				String vendorId = resultSet.getString("vendor_name");
				int productId = resultSet.getInt("ProductNumber");
				System.out.println(productId);
				itemList.add(new ItemDetails(itemId, itemName, quantity, price, vendorId, productId));
			}

			itemTableView.setItems(itemList);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	private void handleRowSelect() {
		ItemDetails selectedItem = itemTableView.getSelectionModel().getSelectedItem();
		if (selectedItem != null) {
			ItemId.setText(selectedItem.getItemId());
			ItemName.setText(selectedItem.getItemName());
			Quantity.setText(String.valueOf(selectedItem.getQuantity()));
			ProductPrice.setText(String.valueOf(selectedItem.getPrice()));
			VendorComboBox.setValue(String.valueOf(selectedItem.getVendor_name()));
			Productid.setText(String.valueOf(selectedItem.getProductId()));

		}
	}

	private void populateVendorComboBox() {
		String fetchVendorsQuery = "SELECT vendor_name FROM vendors";
		try (Connection conn = Connector.connection();
			 Statement statement = conn.createStatement();
			 ResultSet resultSet = statement.executeQuery(fetchVendorsQuery)) {

			while (resultSet.next()) {
				VendorComboBox.getItems().add(resultSet.getString("vendor_name"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void showAlert(Alert.AlertType alertType, String title, String content) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(content);
		alert.showAndWait();
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		CloseButton.setOnMouseClicked(event -> System.exit(0));

		itemIdColumn.setCellValueFactory(cellData -> cellData.getValue().itemIdProperty());
		itemNameColumn.setCellValueFactory(cellData -> cellData.getValue().itemNameProperty());
		quantityColumn.setCellValueFactory(cellData -> cellData.getValue().quantityProperty());
		productPriceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty());
		vendorIdColumn.setCellValueFactory(cellData ->cellData.getValue().vendor_nameProperty());
		productIdColumn.setCellValueFactory(cellData -> cellData.getValue().productIdProperty());
		loadItemsFromDatabase();
		populateVendorComboBox();

		itemTableView.setOnMouseClicked(event -> handleRowSelect());
	}
}
