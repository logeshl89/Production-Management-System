package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Objects;

public class DailyProductionReportController {
	@FXML
	public Button CreateButton;
	@FXML
	private ImageView BackButton;
	@FXML
	private DatePicker EndDate;
	@FXML
	private DatePicker startDate;
	@FXML
	private ComboBox <String> statusComboBox;
	@FXML
	private ImageView CloseButton;
	@FXML
	private Button Back_To_Home;
	@FXML
	private ImageView MinimizeButton;

	@FXML
	private TableView <ProductionReport> productionTableView;

	@FXML
	private TableColumn <ProductionReport, String> machineColumn;

	@FXML
	private TableColumn <ProductionReport, String> fabricatorColumn;

	@FXML
	private TableColumn <ProductionReport, String> projectColumn;

	@FXML
	private TableColumn <ProductionReport, String> productColumn;

	@FXML
	private TableColumn <ProductionReport, String> operationColumn;

	@FXML
	private TableColumn <ProductionReport, Integer> plannedQtyColumn;

	@FXML
	private TableColumn <ProductionReport, Integer> actualQtyColumn;

	@FXML
	private TableColumn <ProductionReport, Integer> rejectedQtyColumn;

	@FXML
	private TableColumn <ProductionReport, String> progressColumn;

	@FXML
	private TableColumn <ProductionReport, Time> startTimeColumn;

	@FXML
	private TableColumn <ProductionReport, Time> endTimeColumn;

	@FXML
	private TextField machineComboBox;

	@FXML
	private TextField searchField;

	@FXML
	private TextField fabricatorComboBox;

	@FXML
	private TextField projectComboBox;

	@FXML
	private TextField operationComboBox;

	@FXML
	private TextField productNameTextField;

	@FXML
	private TextField plannedQtyTextField;

	@FXML
	private TextField actualQtyTextField;

	@FXML
	private TextField rejectedQtyTextField;

	@FXML
	private ComboBox <String> progressTextField;

	@FXML
	private Button refreshButton;

	@FXML
	private Button saveReportButton;
	Parent root;
	Stage stage;
	Scene scene;
	private double xOffset = 0;
	private double yOffset = 0;


	@FXML
	public void initialize() {
		// Set up columns for the ProductionReport TableView
		machineColumn.setCellValueFactory(new PropertyValueFactory <>("machineNumber"));
		fabricatorColumn.setCellValueFactory(new PropertyValueFactory <>("fabricatorName"));
		projectColumn.setCellValueFactory(new PropertyValueFactory <>("projectName"));
		productColumn.setCellValueFactory(new PropertyValueFactory <>("productName"));
		operationColumn.setCellValueFactory(new PropertyValueFactory <>("operationSequence"));
		plannedQtyColumn.setCellValueFactory(new PropertyValueFactory <>("plannedQty"));
		actualQtyColumn.setCellValueFactory(new PropertyValueFactory <>("actualQty"));
		rejectedQtyColumn.setCellValueFactory(new PropertyValueFactory <>("rejectedQty"));
		progressColumn.setCellValueFactory(new PropertyValueFactory <>("progress"));
		startTimeColumn.setCellValueFactory(new PropertyValueFactory <>("startDate"));
		endTimeColumn.setCellValueFactory(new PropertyValueFactory <>("endDate"));
		// Load initial data into the ProductionReport TableView
		refreshTableView();
		CloseButton.setOnMouseClicked(event -> System.exit(0));
		MinimizeButton.setOnMouseClicked(e -> {
			((Stage) ((ImageView) e.getSource()).getScene().getWindow()).setIconified(true);
		});
		productionTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
			if (newSelection != null) {
				try {
					populateFieldsFromSelection(newSelection);
				} catch (DateTimeParseException exception) {
				}
			}
		});
	}

	@FXML
	private Button updateButton;

	@FXML
	public void handleUpdateReport() {
		// Get the selected report from the table
		ProductionReport selectedReport = productionTableView.getSelectionModel().getSelectedItem();
		if (selectedReport == null) {
			// No row is selected, show an alert or return
			return;
		}

		// Retrieve the values from text fields
		String machineNumber = machineComboBox.getText();
		String fabricatorName = fabricatorComboBox.getText();
		String projectName = projectComboBox.getText();
		String productName = productNameTextField.getText();
		String operationSequence = operationComboBox.getText();
		int plannedQty = Integer.parseInt(plannedQtyTextField.getText());
		int actualQty = Integer.parseInt(actualQtyTextField.getText());
		int rejectedQty = Integer.parseInt(rejectedQtyTextField.getText());
		String progress = progressTextField.getValue();

		// Convert DatePicker values to String
		String startTime = startDate.getValue().toString();
		String endTime = EndDate.getValue().toString();

		String updateQuery = "UPDATE DailyProductionReport SET machine_number = ?, fabricator_name = ?, project_name = ?, " +
				"product_name = ?, operation_sequence = ?, planned_qty = ?, actual_qty = ?, rejected_qty = ?, progress = ?, " +
				"start_time = ?, end_time = ? WHERE machine_number = ?";

		try (PreparedStatement pstmt = Connector.connection().prepareStatement(updateQuery)) {
			pstmt.setString(1, machineNumber);
			pstmt.setString(2, fabricatorName);
			pstmt.setString(3, projectName);
			pstmt.setString(4, productName);
			pstmt.setString(5, operationSequence);
			pstmt.setInt(6, plannedQty);
			pstmt.setInt(7, actualQty);
			pstmt.setInt(8, rejectedQty);
			pstmt.setString(9, progress);
			pstmt.setString(10, startTime);
			pstmt.setString(11, endTime);
			pstmt.setString(12, selectedReport.getMachineNumber()); // Use the original machine number for the WHERE clause

			pstmt.executeUpdate();

			// Refresh the table after updating
			refreshTableView();

			// Clear the text fields after update
			clearFields();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void populateFieldsFromSelection(ProductionReport report) {
		machineComboBox.setText(report.getMachineNumber());
		fabricatorComboBox.setText(report.getFabricatorName());
		projectComboBox.setText(report.getProjectName());
		productNameTextField.setText(report.getProductName());
		operationComboBox.setText(report.getOperationSequence());
		plannedQtyTextField.setText(String.valueOf(report.getPlannedQty()));
		actualQtyTextField.setText(String.valueOf(report.getActualQty()));
		rejectedQtyTextField.setText(String.valueOf(report.getRejectedQty()));
		progressTextField.setValue(report.getProgress());
		startDate.setValue(LocalDate.parse(report.getStartDate()));  // Convert String to LocalDate
		EndDate.setValue(LocalDate.parse(report.getEndDate()));      // Convert String to LocalDate
	}

	@FXML
	public void clearFields() {
		// Clear text fields
		machineComboBox.clear();
		fabricatorComboBox.clear();
		projectComboBox.clear();
		productNameTextField.clear();
		operationComboBox.clear();
		plannedQtyTextField.clear();
		actualQtyTextField.clear();
		rejectedQtyTextField.clear();
		progressTextField.setValue(null);

		// Reset ComboBox selection to default
		statusComboBox.getSelectionModel().selectFirst(); // or select a specific default value if needed
		startDate.setValue(null);
		EndDate.setValue(null);
	}

	@FXML
	public void refreshTableView() {
		ObservableList <ProductionReport> productionReports = FXCollections.observableArrayList();
		String query = "SELECT * FROM DailyProductionReport";

		try (Statement stmt = Connector.connection().createStatement();
			 ResultSet rs = stmt.executeQuery(query)) {

			while (rs.next()) {
				ProductionReport report = new ProductionReport(
						rs.getString("machine_number"),
						rs.getString("fabricator_name"),
						rs.getString("project_name"),
						rs.getString("product_name"),
						rs.getString("operation_sequence"),
						rs.getInt("planned_qty"),
						rs.getInt("actual_qty"),
						rs.getInt("rejected_qty"),
						rs.getString("progress"),
						rs.getString("start_time"),
						rs.getString("end_time")
				);
				productionReports.add(report);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		productionTableView.setItems(productionReports);
	}

	@FXML
	public void handleSaveReport() {
		String machineNumber = machineComboBox.getText();
		String fabricatorName = fabricatorComboBox.getText();
		String projectName = projectComboBox.getText();
		String productName = productNameTextField.getText();
		String operationSequence = operationComboBox.getText();
		int plannedQty = Integer.parseInt(plannedQtyTextField.getText());
		int actualQty = Integer.parseInt(actualQtyTextField.getText());
		int rejectedQty = Integer.parseInt(rejectedQtyTextField.getText());
		String progress = progressTextField.getValue();

		// Convert the DatePicker values to String
		String startTime = startDate.getValue().toString();  // Convert LocalDate to String
		String endTime = EndDate.getValue().toString();  // Convert LocalDate to String

		String insertQuery = "INSERT INTO DailyProductionReport (machine_number, fabricator_name, project_name, product_name, operation_sequence, planned_qty, actual_qty, rejected_qty, progress, start_time, end_time, report_date) " +
				"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())";

		try (PreparedStatement pstmt = Connector.connection().prepareStatement(insertQuery)) {
			pstmt.setString(1, machineNumber);
			pstmt.setString(2, fabricatorName);
			pstmt.setString(3, projectName);
			pstmt.setString(4, productName);
			pstmt.setString(5, operationSequence);
			pstmt.setInt(6, plannedQty);
			pstmt.setInt(7, actualQty);
			pstmt.setInt(8, rejectedQty);
			pstmt.setString(9, progress);
			pstmt.setString(10, startTime);  // Storing as string
			pstmt.setString(11, endTime);    // Storing as string

			pstmt.executeUpdate();

			// Refresh the table after saving the report
			refreshTableView();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	@FXML
	public void handleSearch() {
		String searchText = searchField.getText().toLowerCase();

		// Query the database based on the search text
		String query = "SELECT * FROM DailyProductionReport WHERE LOWER(machine_number) LIKE ? OR LOWER(fabricator_name) LIKE ? OR LOWER(project_name) LIKE ? OR LOWER(product_name) LIKE ?";

		try (PreparedStatement preparedStatement = Connector.connection().prepareStatement(query)) {
			String searchPattern = "%" + searchText + "%";
			preparedStatement.setString(1, searchPattern);
			preparedStatement.setString(2, searchPattern);
			preparedStatement.setString(3, searchPattern);
			preparedStatement.setString(4, searchPattern);

			ResultSet resultSet = preparedStatement.executeQuery();
			ObservableList <ProductionReport> filteredReports = FXCollections.observableArrayList();

			while (resultSet.next()) {
				ProductionReport report = new ProductionReport(
						resultSet.getString("machine_number"),
						resultSet.getString("fabricator_name"),
						resultSet.getString("project_name"),
						resultSet.getString("product_name"),
						resultSet.getString("operation_sequence"),
						resultSet.getInt("planned_qty"),
						resultSet.getInt("actual_qty"),
						resultSet.getInt("rejected_qty"),
						resultSet.getString("progress"),
						resultSet.getString("start_time"),   // Changed Time to String
						resultSet.getString("end_time")      // Changed Time to String
				);
				filteredReports.add(report);
			}

			productionTableView.setItems(filteredReports);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	@FXML
	public void handleSaveReportEXCEL(ActionEvent actionEvent) {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Production Report");

		// Create header row
		Row headerRow = sheet.createRow(0);
		String[] headers = {"Machine Number", "Fabricator Name", "Project Name", "Product Name", "Operation Sequence", "Planned Qty", "Actual Qty", "Rejected Qty", "Progress", "Start Time", "End Time"};
		for (int i = 0; i < headers.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(headers[i]);
		}

		// Populate the rows with data from TableView
		ObservableList <ProductionReport> reports = productionTableView.getItems();
		int rowIndex = 1;
		for (ProductionReport report : reports) {
			Row row = sheet.createRow(rowIndex++);

			row.createCell(0).setCellValue(report.getMachineNumber());
			row.createCell(1).setCellValue(report.getFabricatorName());
			row.createCell(2).setCellValue(report.getProjectName());
			row.createCell(3).setCellValue(report.getProductName());
			row.createCell(4).setCellValue(report.getOperationSequence());
			row.createCell(5).setCellValue(report.getPlannedQty());
			row.createCell(6).setCellValue(report.getActualQty());
			row.createCell(7).setCellValue(report.getRejectedQty());
			row.createCell(8).setCellValue(report.getProgress());
			row.createCell(9).setCellValue(report.getStartDate());
			row.createCell(10).setCellValue(report.getEndDate());
		}

		// Auto-size columns
		for (int i = 0; i < headers.length; i++) {
			sheet.autoSizeColumn(i);
		}

		// Write the output to a file
		try (FileOutputStream fileOut = new FileOutputStream("DailyProductionReport.xlsx")) {
			workbook.write(fileOut);
			System.out.println("Excel file has been generated!");
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void handleStatusFilter() {
		String selectedStatus = statusComboBox.getValue();
		System.out.println("Selected Status: " + selectedStatus); // Debug statement

		String query;
		if ("All".equals(selectedStatus)) {
			query = "SELECT * FROM DailyProductionReport";
		} else {
			query = "SELECT * FROM DailyProductionReport WHERE progress = ?";
		}

		try (PreparedStatement preparedStatement = Connector.connection().prepareStatement(query)) {
			if (!"All".equals(selectedStatus)) {
				preparedStatement.setString(1, selectedStatus);
			}

			ResultSet resultSet = preparedStatement.executeQuery();
			ObservableList <ProductionReport> filteredReports = FXCollections.observableArrayList();

			while (resultSet.next()) {
				ProductionReport report = new ProductionReport(
						resultSet.getString("machine_number"),
						resultSet.getString("fabricator_name"),
						resultSet.getString("project_name"),
						resultSet.getString("product_name"),
						resultSet.getString("operation_sequence"),
						resultSet.getInt("planned_qty"),
						resultSet.getInt("actual_qty"),
						resultSet.getInt("rejected_qty"),
						resultSet.getString("progress"),
						resultSet.getString("start_time"),
						resultSet.getString("end_time")
				);
				filteredReports.add(report);
			}

			productionTableView.setItems(filteredReports);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void Switch_To_Dashboard(ActionEvent event) throws IOException {
		root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("DashBoardProduction.fxml")));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	private Button deleteButton;

	@FXML
	public void handleDeleteRow() {
		// Get the selected row
		ProductionReport selectedReport = productionTableView.getSelectionModel().getSelectedItem();

		if (selectedReport != null) {
			// Confirmation dialog before deletion
			Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			alert.setTitle("Delete Confirmation");
			alert.setHeaderText(null);
			alert.setContentText("Are you sure you want to delete this report?");

			ButtonType yesButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
			ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
			alert.getButtonTypes().setAll(yesButton, noButton);

			// If the user confirms the deletion
			alert.showAndWait().ifPresent(response -> {
				if (response == yesButton) {
					// Delete from the database
					String deleteQuery = "DELETE FROM DailyProductionReport WHERE machine_number = ? AND fabricator_name = ? AND project_name = ? AND product_name = ?";

					try (PreparedStatement pstmt = Connector.connection().prepareStatement(deleteQuery)) {
						pstmt.setString(1, selectedReport.getMachineNumber());
						pstmt.setString(2, selectedReport.getFabricatorName());
						pstmt.setString(3, selectedReport.getProjectName());
						pstmt.setString(4, selectedReport.getProductName());

						int rowsAffected = pstmt.executeUpdate();
						if (rowsAffected > 0) {
							// Remove the selected item from the TableView
							productionTableView.getItems().remove(selectedReport);
							System.out.println("Report deleted successfully!");
						} else {
							System.out.println("Failed to delete the report from the database.");
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			});
		} else {
			// Show an alert if no row is selected
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setTitle("No Selection");
			alert.setHeaderText(null);
			alert.setContentText("Please select a report to delete.");
			alert.showAndWait();
		}
	}

}
