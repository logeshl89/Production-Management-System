package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class OverView implements Initializable {

	@FXML
	private PieChart itemPieChart; // Fixed naming convention

	@FXML
	private TableView <ItemDetails> itemTableView;

	@FXML
	private TableColumn <ItemDetails, Number> productIdColumn;

	@FXML
	private TableColumn <ItemDetails, String> itemIdColumn;

	@FXML
	private TableColumn <ItemDetails, String> itemNameColumn;

	@FXML
	private TableColumn <ItemDetails, Number> quantityColumn;

	@FXML
	private TableColumn <ItemDetails, Number> productPriceColumn;

	@FXML
	private TableColumn <ItemDetails, String> vendorIdColumn;

	private ObservableList <ItemDetails> itemList = FXCollections.observableArrayList();

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		loadItemsFromDatabase();

		itemIdColumn.setCellValueFactory(cellData -> cellData.getValue().itemIdProperty());
		itemNameColumn.setCellValueFactory(cellData -> cellData.getValue().itemNameProperty());
		quantityColumn.setCellValueFactory(cellData -> cellData.getValue().quantityProperty());
		productPriceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty());
		vendorIdColumn.setCellValueFactory(cellData -> cellData.getValue().vendor_nameProperty());
		productIdColumn.setCellValueFactory(cellData -> cellData.getValue().productIdProperty());
		loadItemsFromDatabase();

		initializePieCharts();
	}

	private void initializePieCharts() {
		String itemQuery = "SELECT product_name, SUM(quantity) AS total_quantity FROM sales GROUP BY product_name";

		try (Connection conn = Connector.connection();
			 PreparedStatement itemStmt = conn.prepareStatement(itemQuery)) {

			// Product Pie Chart
			ResultSet rsItem = itemStmt.executeQuery();
			ObservableList <PieChart.Data> itemData = FXCollections.observableArrayList();
			while (rsItem.next()) {
				String productName = rsItem.getString("product_name");
				int quantity = rsItem.getInt("total_quantity");
				itemData.add(new PieChart.Data(productName, quantity));
			}
			itemPieChart.setData(itemData);
			rsItem.close();

		} catch (SQLException e) {
			e.printStackTrace();  // Handle SQL exceptions properly in a real application
		}
	}

	private void loadItemsFromDatabase() {
		String query = "SELECT * FROM items";
		try (Connection conn = Connector.connection();
			 Statement statement = conn.createStatement();
			 ResultSet resultSet = statement.executeQuery(query)) {

			itemList.clear();

			while (resultSet.next()) {
				if (resultSet.getInt("quantity") < 20) {
					String itemId = resultSet.getString("item_id");
					String itemName = resultSet.getString("item_name");
					int quantity = resultSet.getInt("quantity");
					int price = resultSet.getInt("price");
					String vendorId = resultSet.getString("vendor_name");
					int productId = resultSet.getInt("ProductNumber");
					itemList.add(new ItemDetails(itemId, itemName, quantity, price, vendorId, productId));
				}
			}


			itemTableView.setItems(itemList);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	// Inner class to represent the data in the store_management table
	public static class StoreManagementData {
		private final Integer transactionId;
		private final Integer itemId;
		private final String transactionType;
		private final Integer quantity;
		private final Timestamp transactionDate;

		public StoreManagementData(Integer transactionId, Integer itemId, String transactionType, Integer quantity, Timestamp transactionDate) {
			this.transactionId = transactionId;
			this.itemId = itemId;
			this.transactionType = transactionType;
			this.quantity = quantity;
			this.transactionDate = transactionDate;
		}

		public Integer getTransactionId() {
			return transactionId;
		}

		public Integer getItemId() {
			return itemId;
		}

		public String getTransactionType() {
			return transactionType;
		}

		public Integer getQuantity() {
			return quantity;
		}

		public Timestamp getTransactionDate() {
			return transactionDate;
		}
	}
}
