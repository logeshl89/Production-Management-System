package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class VendorController implements Initializable {

	public TextField vendorNameField;
	public TextField vendorTypeField;
	public TextField emailField;
	public TextField contactInfoField;
	public TextField addressField;
	public Button saveVendorButton;
	@FXML
	private ComboBox<String> Courses; // ComboBox for courses

	@FXML
	private ComboBox<String> vendorComboBox; // ComboBox for selecting vendors

	@FXML
	private Button filterButton; // Button to process the selection

	@FXML
	private Button Reload; // Button to reload data

	@FXML
	private TableView<Vendor> vendorTableView; // TableView for vendors

	@FXML
	private TableColumn<Vendor, Integer> VendorIdColumn; // Column for vendor ID

	@FXML
	private TableColumn<Vendor, String> VendorNameColumn; // Column for vendor name

	@FXML
	private TableColumn<Vendor, String> VendorTypeColumn; // Column for vendor type

	@FXML
	private TableColumn<Vendor, String> VendorEmailColumn; // Column for vendor email

	@FXML
	private TableColumn<Vendor, String> VendorAddressColumn; // Column for vendor address

	@FXML
	private TableColumn<Vendor, String> VendorContactColumn; // Column for vendor contact

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		// Initialize TableView and columns
		VendorIdColumn.setCellValueFactory(new PropertyValueFactory<>("vendorId"));
		VendorNameColumn.setCellValueFactory(new PropertyValueFactory<>("vendorName"));
		VendorTypeColumn.setCellValueFactory(new PropertyValueFactory<>("vendorType"));
		VendorEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
		VendorAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
		VendorContactColumn.setCellValueFactory(new PropertyValueFactory<>("contactInfo"));

		// Load vendor data from the database
		loadVendorData();

		// Add event handlers
	}

	private void loadVendorData() {

		ObservableList<Vendor> vendorList = FXCollections.observableArrayList();
		String query = "SELECT vendor_id, vendor_name, vendor_type, email, address, contact_info FROM vendors";

		try (Connection connection = Connector.connection();
			 PreparedStatement preparedStatement = connection.prepareStatement(query);
			 ResultSet resultSet = preparedStatement.executeQuery()) {

			while (resultSet.next()) {
				int vendorId = resultSet.getInt("vendor_id");
				String vendorName = resultSet.getString("vendor_name");
				String vendorType = resultSet.getString("vendor_type");
				String email = resultSet.getString("email");
				String address = resultSet.getString("address");
				String contactInfo = resultSet.getString("contact_info");

				Vendor vendor = new Vendor(vendorId, vendorName, vendorType, email, address, contactInfo);
				vendorList.add(vendor);
			}

			vendorTableView.setItems(vendorList);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	@FXML
	public void saveVendor() {
		String vendorName = vendorNameField.getText();
		String vendorType = vendorTypeField.getText();
		String email = emailField.getText();
		String address = addressField.getText();
		String contactInfo = contactInfoField.getText();

		// Call the addVendor method to save to the database
		if (isValidInput(vendorName, email)) {
			addVendor(vendorName, vendorType, email, address, contactInfo);
		} else {
			System.out.println("Please fill in required fields.");
		}
	}
	private boolean isValidInput(String vendorName, String email) {
		// Check if vendorName and email are not empty
		return vendorName != null && !vendorName.isEmpty() && email != null && !email.isEmpty();
	}
	private void addVendor(String vendorName, String vendorType, String email, String address, String contactInfo) {
		// Your existing addVendor method
		String query = "INSERT INTO vendors (vendor_name, vendor_type, email, address, contact_info) VALUES (?, ?, ?, ?, ?)";

		try (PreparedStatement preparedStatement = Connector.connection().prepareStatement(query)) {
			preparedStatement.setString(1, vendorName);
			preparedStatement.setString(2, vendorType);
			preparedStatement.setString(3, email);
			preparedStatement.setString(4, address);
			preparedStatement.setString(5, contactInfo);

			int rowsAffected = preparedStatement.executeUpdate();
			if (rowsAffected > 0) {
				loadVendorData();
				System.out.println("Vendor added successfully.");
			} else {
				System.out.println("Failed to add vendor.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private void handleFilter() {
		// Implement filter logic based on selected items in the ComboBox
		String selectedCourse = Courses.getValue();
		String selectedVendor = vendorComboBox.getValue();

		// Add filtering logic here based on the selected course and vendor
	}

}
