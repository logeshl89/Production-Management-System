package com.example.Production_management_system;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

public class DashBoard implements Initializable {
    PreparedStatement preparedStatement;
    @FXML
    private StackPane backgroundPane;
    Alert alert;
    @FXML
    private Button UpdateButton;

    private boolean isAlert=true;
    @FXML
    private Button OverAllViewButton;
    @FXML
    private Button NewUserButton;
    @FXML
    private Button NewTeacherUserButton;
   @FXML
    private ImageView CloseButton;
    private Stage stage;
    private Scene scene;

    @FXML
    private  ImageView MinimizeButton;
    @FXML
    private Label UsernameUpload;
    @FXML
    private Button OnPressAllTheUsers;
    static String usernamestr;
    Parent root;

    void SetText(String username) {
        usernamestr = username;
        UsernameUpload.setText("Welcome,back " + usernamestr);
    }
    void OrginalText() {
        UsernameUpload.setText("Welcome,back " + usernamestr);
    }


    @FXML
    void LogOut(ActionEvent event) throws IOException {
        alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("LogOut!");
        alert.setHeaderText("Are you sure to logout");
        Optional<ButtonType> buttonType = alert.showAndWait();
        if (buttonType.get() == ButtonType.OK) {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Login.fxml")));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    void NewSceneChanger(ActionEvent event) throws IOException {
        if(event.getSource()==NewUserButton)
        {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("NewUser_Registration.fxml")));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
        else if(event.getSource()==UpdateButton)
        {
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Product_Update.fxml")));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    protected void ChangingTheScene(ActionEvent event) throws IOException {
        if (event.getSource() == OnPressAllTheUsers) {
            root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Person.fxml")));
            backgroundPane.getChildren().removeAll();
            backgroundPane.getChildren().setAll(root);
        }

else if (event.getSource()==NewTeacherUserButton) {
            root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("NewTeacher.fxml")));
            backgroundPane.getChildren().removeAll();
            backgroundPane.getChildren().setAll(root);
        }
        else if(event.getSource()==OverAllViewButton)
        {
            root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("OverView.fxml")));
            backgroundPane.getChildren().removeAll();
            backgroundPane.getChildren().setAll(root);
        }
    }
    private double xOffset = 0;
    private double yOffset = 0;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        CloseButton.setOnMouseClicked(event -> System.exit(0));
        OrginalText();
        try {
            root=FXMLLoader.load(Objects.requireNonNull(getClass().getResource("OverView.fxml")));
            checkItemQuantities();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        backgroundPane.getChildren().removeAll();
        backgroundPane.getChildren().setAll(root);
        MinimizeButton.setOnMouseClicked(e -> {
            ((Stage)((ImageView)e.getSource()).getScene().getWindow()).setIconified(true);
        });
        root.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                xOffset = event.getSceneX();
                yOffset = event.getSceneY();
            }
        });

        root.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                stage.setX(event.getScreenX() - xOffset);
                stage.setY(event.getScreenY() - yOffset);
            }
        });

    }
    private void checkItemQuantities() {
        if(isAlert) {
            String query = "SELECT item_name, quantity FROM items";
            try (Statement statement = Connector.connection().createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {

                boolean lowStock = false;
                boolean highStock = false;
                StringBuilder lowStockItems = new StringBuilder();
                StringBuilder highStockItems = new StringBuilder();

                while (resultSet.next()) {
                    String itemName = resultSet.getString("item_name");
                    int quantity = resultSet.getInt("quantity");

                    if (quantity < 25) {
                        lowStock = true;
                        lowStockItems.append(itemName).append(": ").append(quantity).append("\n");
                    } else {
                        highStock = true;
                        highStockItems.append(itemName).append(": ").append(quantity).append("\n");
                    }
                }

                if (lowStock || highStock) {
                    StringBuilder alertMessage = new StringBuilder();
                    if (lowStock) {
                        alertMessage.append("Low stock items:\n").append(lowStockItems);
                    }
                    if (highStock) {
                        alertMessage.append("\nHigh stock items:\n").append(highStockItems);
                    }
                    showAlert(Alert.AlertType.INFORMATION, "Stock Alert", alertMessage.toString());
                }


            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to check item quantities.");
            }
        }
    }
    private void showAlert(Alert.AlertType alertType, String title, String content) {

        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null); // Optional: Set header text if needed
        alert.setContentText(content);
        alert.showAndWait();
        isAlert=false;
    }
}