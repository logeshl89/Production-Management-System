package com.example.Production_management_system;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SalesTransaction {

	private final StringProperty transactionId;
	private final StringProperty productName;
	private final StringProperty quantity;
	private final StringProperty price;

	public SalesTransaction(String transactionId, String productName, String quantity, String price) {
		this.transactionId = new SimpleStringProperty(transactionId);
		this.productName = new SimpleStringProperty(productName);
		this.quantity = new SimpleStringProperty(quantity);
		this.price = new SimpleStringProperty(price);
	}

	public String getTransactionId() {
		return transactionId.get();
	}

	public void setTransactionId(String transactionId) {
		this.transactionId.set(transactionId);
	}

	public StringProperty transactionIdProperty() {
		return transactionId;
	}

	public String getProductName() {
		return productName.get();
	}

	public void setProductName(String productName) {
		this.productName.set(productName);
	}

	public StringProperty productNameProperty() {
		return productName;
	}

	public String getQuantity() {
		return quantity.get();
	}

	public void setQuantity(String quantity) {
		this.quantity.set(quantity);
	}

	public StringProperty quantityProperty() {
		return quantity;
	}

	public String getPrice() {
		return price.get();
	}

	public void setPrice(String price) {
		this.price.set(price);
	}

	public StringProperty priceProperty() {
		return price;
	}
}
