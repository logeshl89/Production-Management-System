package com.example.Production_management_system;

import javafx.collections.ObservableList;

import java.io.File;

public class PdfReportGenerator {
	public static void generatePDF(File file, ObservableList<Customer> customerList) {
	}
}
