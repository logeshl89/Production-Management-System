package com.example.Production_management_system;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class User {

	private final StringProperty userId;
	private final StringProperty userName;
	private final StringProperty userEmail;

	public User(String userId, String userName, String userEmail) {
		this.userId = new SimpleStringProperty(userId);
		this.userName = new SimpleStringProperty(userName);
		this.userEmail = new SimpleStringProperty(userEmail);
	}

	public StringProperty userIdProperty() {
		return userId;
	}

	public String getUserId() {
		return userId.get();
	}

	public void setUserId(String userId) {
		this.userId.set(userId);
	}

	public StringProperty userNameProperty() {
		return userName;
	}

	public String getUserName() {
		return userName.get();
	}

	public void setUserName(String userName) {
		this.userName.set(userName);
	}

	public StringProperty userEmailProperty() {
		return userEmail;
	}

	public String getUserEmail() {
		return userEmail.get();
	}

	public void setUserEmail(String userEmail) {
		this.userEmail.set(userEmail);
	}
}
