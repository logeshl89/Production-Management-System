package com.example.Production_management_system;

public class ProductionReport {
	private String machineNumber;
	private String fabricatorName;
	private String projectName;
	private String productName;
	private String operationSequence;
	private int plannedQty;
	private int actualQty;
	private int rejectedQty;
	private String progress;
	private String startDate;
	private String endDate;

	public String getMachineNumber() {
		return machineNumber;
	}

	public void setMachineNumber(String machineNumber) {
		this.machineNumber = machineNumber;
	}

	public String getFabricatorName() {
		return fabricatorName;
	}

	public void setFabricatorName(String fabricatorName) {
		this.fabricatorName = fabricatorName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getOperationSequence() {
		return operationSequence;
	}

	public void setOperationSequence(String operationSequence) {
		this.operationSequence = operationSequence;
	}

	public int getPlannedQty() {
		return plannedQty;
	}

	public void setPlannedQty(int plannedQty) {
		this.plannedQty = plannedQty;
	}

	public int getActualQty() {
		return actualQty;
	}

	public void setActualQty(int actualQty) {
		this.actualQty = actualQty;
	}

	public int getRejectedQty() {
		return rejectedQty;
	}

	public void setRejectedQty(int rejectedQty) {
		this.rejectedQty = rejectedQty;
	}

	public String getProgress() {
		return progress;
	}

	public void setProgress(String progress) {
		this.progress = progress;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public ProductionReport(String machineNumber, String fabricatorName, String projectName, String productName, String operationSequence, int plannedQty, int actualQty, int rejectedQty, String progress, String startDate, String endDate) {
		this.machineNumber = machineNumber;
		this.fabricatorName = fabricatorName;
		this.projectName = projectName;
		this.productName = productName;
		this.operationSequence = operationSequence;
		this.plannedQty = plannedQty;
		this.actualQty = actualQty;
		this.rejectedQty = rejectedQty;
		this.progress = progress;
		this.startDate = startDate;
		this.endDate = endDate;
	}
}
