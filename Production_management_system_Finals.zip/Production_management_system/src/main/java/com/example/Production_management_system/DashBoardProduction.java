package com.example.Production_management_system;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

public class DashBoardProduction implements Initializable {
	private double xOffset = 0;
	private double yOffset = 0;
	@FXML
	private Button AddNewProduct;

	@FXML
	private Button ReportGenerationMain;
	@FXML
	private ImageView CloseButton;

	@FXML
	private ImageView MinimizeButton;

	@FXML
	private Button OverAllViewButton;

	@FXML
	private Button ReportGeneration;



	@FXML
	private Label UsernameUpload;
	private Stage stage;
	private Scene scene;
	@FXML
	private StackPane backgroundPane;
	Parent root;


	@FXML
	void ChangingTheScene(ActionEvent event) throws IOException {

		if (event.getSource() == OverAllViewButton) {
			root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Overview.fxml")));
			backgroundPane.getChildren().removeAll();
			backgroundPane.getChildren().setAll(root);
		} else if (event.getSource() == AddNewProduct) {
			root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ProductionAddition.fxml")));
			backgroundPane.getChildren().removeAll();
			backgroundPane.getChildren().setAll(root);
		} else if (event.getSource() == ReportGeneration) {
			root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ProductionDataReport.fxml")));
			backgroundPane.getChildren().removeAll();
			backgroundPane.getChildren().setAll(root);
		}
		else if (event.getSource() == ReportGenerationMain) {
			Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Productionui.fxml")));
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}
	}

	Alert alert;

	@FXML
	void LogOut(ActionEvent event) throws IOException {
		alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("LogOut!");
		alert.setHeaderText("Are you sure to logout");
		Optional <ButtonType> buttonType = alert.showAndWait();
		if (buttonType.get() == ButtonType.OK) {
			Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Login.fxml")));
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}
	}


	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		CloseButton.setOnMouseClicked(event -> System.exit(0));
		try {
			root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("OverView.fxml")));

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		backgroundPane.getChildren().removeAll();
		backgroundPane.getChildren().setAll(root);
		MinimizeButton.setOnMouseClicked(e -> {
			((Stage) ((ImageView) e.getSource()).getScene().getWindow()).setIconified(true);
		});
		root.setOnMousePressed(new EventHandler <MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				xOffset = event.getSceneX();
				yOffset = event.getSceneY();
			}
		});

		root.setOnMouseDragged(new EventHandler <MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				stage.setX(event.getScreenX() - xOffset);
				stage.setY(event.getScreenY() - yOffset);
			}
		});

	}
}
