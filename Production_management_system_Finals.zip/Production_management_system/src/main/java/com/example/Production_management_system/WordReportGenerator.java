package com.example.Production_management_system;

import org.apache.poi.xwpf.usermodel.*;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class WordReportGenerator {

	public void generateReport(List<Customer> customers) {
		XWPFDocument document = new XWPFDocument();

		// Title
		XWPFParagraph titleParagraph = document.createParagraph();
		XWPFRun titleRun = titleParagraph.createRun();
		titleRun.setText("Day Report");
		titleRun.setBold(true);
		titleRun.setFontSize(20);

		// Table
		XWPFTable table = document.createTable();
		XWPFTableRow headerRow = table.getRow(0);
		headerRow.getCell(0).setText("ID");
		headerRow.addNewTableCell().setText("Name");
		headerRow.addNewTableCell().setText("Phone Number");
		headerRow.addNewTableCell().setText("Product Price");
		headerRow.addNewTableCell().setText("Initial Payment");
		headerRow.addNewTableCell().setText("Complaint");
		headerRow.addNewTableCell().setText("Date of Entry");
		headerRow.addNewTableCell().setText("Status");

		for (Customer customer : customers) {
			XWPFTableRow row = table.createRow();
			row.getCell(0).setText(String.valueOf(customer.getCustomerId()));
			row.getCell(1).setText(customer.getCustomerName());
			row.getCell(2).setText(customer.getCustomerPhone());
			row.getCell(3).setText(String.format("%.2f", customer.getProductPrice()));
			row.getCell(4).setText(String.format("%.2f", customer.getInitialPayment()));
			row.getCell(5).setText(customer.getComplaint());
			row.getCell(6).setText(customer.getDateOfEntry().toString());
			row.getCell(7).setText(customer.getStatus());
		}

		// Save the document
		try (FileOutputStream out = new FileOutputStream("CustomerReport.docx")) {
			document.write(out);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
