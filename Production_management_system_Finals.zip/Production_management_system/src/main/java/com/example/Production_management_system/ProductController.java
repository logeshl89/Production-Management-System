package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class ProductController implements Initializable {

    @FXML
    private TableColumn<Product, String> ProductIDColumn;

    @FXML
    private TableColumn<Product, String> ProductNameColumn;

    @FXML
    private TableColumn<Product, String> ProductCategoryColumn;

    @FXML
    private TableColumn<Product, String> ProductPriceColumn;

    @FXML
    private TableColumn<Product, String> ProductQuantityColumn;

    @FXML
    private Button filterButton;

    @FXML
    private ComboBox<String> CategoryComboBox;

    @FXML
    private TableView<Product> ProductTableView;

    @FXML
    private Button reloadButton;

    private PreparedStatement preparedStatement;
    private Statement statement;

    @FXML
    public void updateTable(ResultSet resultSet) throws SQLException {
        ObservableList<Product> productsList = FXCollections.observableArrayList();

        while (resultSet.next()) {
            Product product = new Product();
            product.setId(resultSet.getString("product_id"));
            product.setName(resultSet.getString("product_name"));
            product.setCategory(resultSet.getString("product_category"));
            product.setPrice(resultSet.getString("product_price"));
            product.setQuantity(resultSet.getString("product_quantity"));
            productsList.add(product);
        }

        ProductTableView.setItems(productsList);
        ProductIDColumn.setCellValueFactory(f -> f.getValue().idProperty());
        ProductNameColumn.setCellValueFactory(f -> f.getValue().nameProperty());
        ProductCategoryColumn.setCellValueFactory(f -> f.getValue().categoryProperty());
        ProductPriceColumn.setCellValueFactory(f -> f.getValue().priceProperty());
        ProductQuantityColumn.setCellValueFactory(f -> f.getValue().quantityProperty());
    }

    @FXML
    protected void onClickFilter() throws SQLException {
        if (CategoryComboBox.getValue() == null) {
            preparedStatement = Connector.connection().prepareStatement("SELECT * FROM products;");
            ResultSet resultSet = preparedStatement.executeQuery();
            updateTable(resultSet);
        } else {
            preparedStatement = Connector.connection().prepareStatement("SELECT * FROM products WHERE product_category = ?;");
            preparedStatement.setString(1, CategoryComboBox.getValue());
            ResultSet resultSet = preparedStatement.executeQuery();
            updateTable(resultSet);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            reloadCategories();
            CategoryComboBox.getItems().add("All Categories");  // Optional default option
            ResultSet resultSet = Connector.connection().createStatement().executeQuery("SELECT * FROM products;");
            updateTable(resultSet);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    private void reloadCategories() throws SQLException {
        String query = "SELECT DISTINCT product_category FROM products;";
        statement = Connector.connection().createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()) {
            CategoryComboBox.getItems().add(resultSet.getString(1));
        }
    }

    @FXML
    private void showAllProducts() throws SQLException {
        ResultSet resultSet = Connector.connection().createStatement().executeQuery("SELECT * FROM products;");
        updateTable(resultSet);
        CategoryComboBox.setValue(null);
    }
}
