package com.example.Production_management_system;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Operator {
	private int id;
	private SimpleStringProperty operatorName;
	private SimpleStringProperty phoneNumber;
	private SimpleStringProperty gender;
	private SimpleStringProperty email;
	private SimpleStringProperty specialization;


	public Operator(int id, String operatorName, String phoneNumber, String gender, String email, String specialization) {
		this.id = id;
		this.operatorName = new SimpleStringProperty(operatorName);
		this.phoneNumber = new SimpleStringProperty(phoneNumber);
		this.gender = new SimpleStringProperty(gender);
		this.specialization = new SimpleStringProperty(specialization);
		this.email = new SimpleStringProperty(email);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOperatorName() {
		return operatorName.get();
	}

	public SimpleStringProperty operatorNameProperty() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName.set(operatorName);
	}

	public String getPhoneNumber() {
		return phoneNumber.get();
	}

	public SimpleStringProperty phoneNumberProperty() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.set(phoneNumber);
	}

	public String getGender() {
		return gender.get();
	}

	public SimpleStringProperty genderProperty() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender.set(gender);
	}

	public String getEmail() {
		return email.get();
	}

	public SimpleStringProperty emailProperty() {
		return email;
	}

	public void setEmail(String email) {
		this.email.set(email);
	}

	public String getSpecialization() {
		return specialization.get();
	}

	public SimpleStringProperty specializationProperty() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization.set(specialization);
	}
}