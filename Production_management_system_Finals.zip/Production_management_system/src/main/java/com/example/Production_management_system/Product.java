package com.example.Production_management_system;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Product {

	private final StringProperty id;
	private final StringProperty name;
	private final StringProperty category;
	private final StringProperty price;
	private final StringProperty quantity;
	private final StringProperty username;
	private final StringProperty usernameOfTheOperator;

	public Product() {
		this.id = new SimpleStringProperty("");
		this.name = new SimpleStringProperty("");
		this.category = new SimpleStringProperty("");
		this.price = new SimpleStringProperty("");
		this.quantity = new SimpleStringProperty("");
		this.username = new SimpleStringProperty("");
		this.usernameOfTheOperator = new SimpleStringProperty("");
	}

	// Getter and Setter for id
	public String getId() {
		return id.get();
	}

	public void setId(String id) {
		this.id.set(id);
	}

	public StringProperty idProperty() {
		return id;
	}

	// Getter and Setter for name
	public String getName() {
		return name.get();
	}

	public void setName(String name) {
		this.name.set(name);
	}

	public StringProperty nameProperty() {
		return name;
	}

	// Getter and Setter for category
	public String getCategory() {
		return category.get();
	}

	public void setCategory(String category) {
		this.category.set(category);
	}

	public StringProperty categoryProperty() {
		return category;
	}

	// Getter and Setter for price
	public String getPrice() {
		return price.get();
	}

	public void setPrice(String price) {
		this.price.set(price);
	}

	public StringProperty priceProperty() {
		return price;
	}

	// Getter and Setter for quantity
	public String getQuantity() {
		return quantity.get();
	}

	public void setQuantity(String quantity) {
		this.quantity.set(quantity);
	}

	public StringProperty quantityProperty() {
		return quantity;
	}

	// Getter and Setter for username
	public String getUsername() {
		return username.get();
	}

	public void setUsername(String username) {
		this.username.set(username);
	}

	public StringProperty usernameProperty() {
		return username;
	}

	// Getter and Setter for usernameOfTheOperator
	public String getUsernameOfTheOperator() {
		return usernameOfTheOperator.get();
	}

	public void setUsernameOfTheOperator(String usernameOfTheOperator) {
		this.usernameOfTheOperator.set(usernameOfTheOperator);
	}

	public StringProperty usernameOfTheOperatorProperty() {
		return usernameOfTheOperator;
	}
}

