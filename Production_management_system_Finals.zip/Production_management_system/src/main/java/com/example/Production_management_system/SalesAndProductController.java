package com.example.Production_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class SalesAndProductController implements Initializable {

	@FXML
	private TableView<SalesTransaction> salesTableView;

	@FXML
	private TableColumn<SalesTransaction, String> transactionIdColumn;
	@FXML
	private TableColumn<SalesTransaction, String> productNameColumn;
	@FXML
	private TableColumn<SalesTransaction, String> quantityColumn;
	@FXML
	private TableColumn<SalesTransaction, String> priceColumn;

	@FXML
	private PieChart productPieChart;
	@FXML
	private PieChart salesPieChart;

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		try {
			connection = Connector.connection();

			// Initialize TableView columns
			transactionIdColumn.setCellValueFactory(new PropertyValueFactory<>("transactionId"));
			productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
			quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
			priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

			// Load data into TableView
			loadSalesData();

			// Load data into PieCharts
			loadProductPieChartData();
			loadSalesPieChartData();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void loadSalesData() throws SQLException {
		String query = "SELECT transaction_id, product_name, quantity, price FROM sales_transactions " +
				"ORDER BY transaction_date DESC LIMIT 4";
		preparedStatement = connection.prepareStatement(query);
		resultSet = preparedStatement.executeQuery();

		ObservableList<SalesTransaction> salesList = FXCollections.observableArrayList();
		while (resultSet.next()) {
			SalesTransaction transaction = new SalesTransaction(
					resultSet.getString("transaction_id"),
					resultSet.getString("product_name"),
					resultSet.getString("quantity"),
					resultSet.getString("price")
			);
			salesList.add(transaction);
		}
		salesTableView.setItems(salesList);
	}

	private void loadProductPieChartData() throws SQLException {
		String query = "SELECT product_name, SUM(quantity) as total_quantity FROM sales_transactions GROUP BY product_name";
		preparedStatement = connection.prepareStatement(query);
		resultSet = preparedStatement.executeQuery();

		ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
		while (resultSet.next()) {
			String productName = resultSet.getString("product_name");
			int totalQuantity = resultSet.getInt("total_quantity");
			pieChartData.add(new PieChart.Data(productName, totalQuantity));
		}
		productPieChart.setData(pieChartData);
	}

	private void loadSalesPieChartData() throws SQLException {
		String query = "SELECT product_name, SUM(price * quantity) as total_sales FROM sales_transactions GROUP BY product_name";
		preparedStatement = connection.prepareStatement(query);
		resultSet = preparedStatement.executeQuery();

		ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
		while (resultSet.next()) {
			String productName = resultSet.getString("product_name");
			double totalSales = resultSet.getDouble("total_sales");
			pieChartData.add(new PieChart.Data(productName, totalSales));
		}
		salesPieChart.setData(pieChartData);
	}
}
