package com.example.Production_management_system;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

import java.time.LocalDate;

public class Customer {
	private final IntegerProperty customerId;
	private final StringProperty customerName;
	private final StringProperty customerPhone;
	private final DoubleProperty productPrice;
	private final DoubleProperty initialPayment;
	private final StringProperty complaint;
	private final ObjectProperty<LocalDate> dateOfEntry;
	private final StringProperty status;

	public Customer(int customerId, String customerName, String customerPhone, double productPrice,
					double initialPayment, String complaint, LocalDate dateOfEntry, String status) {
		this.customerId = new SimpleIntegerProperty(customerId);
		this.customerName = new SimpleStringProperty(customerName);
		this.customerPhone = new SimpleStringProperty(customerPhone);
		this.productPrice = new SimpleDoubleProperty(productPrice);
		this.initialPayment = new SimpleDoubleProperty(initialPayment);
		this.complaint = new SimpleStringProperty(complaint);
		this.dateOfEntry = new SimpleObjectProperty<>(dateOfEntry);
		this.status = new SimpleStringProperty(status);
	}

	public IntegerProperty customerIdProperty() {
		return customerId;
	}

	public StringProperty customerNameProperty() {
		return customerName;
	}

	public StringProperty customerPhoneProperty() {
		return customerPhone;
	}

	public DoubleProperty productPriceProperty() {
		return productPrice;
	}

	public DoubleProperty initialPaymentProperty() {
		return initialPayment;
	}

	public StringProperty complaintProperty() {
		return complaint;
	}

	public ObjectProperty<LocalDate> dateOfEntryProperty() {
		return dateOfEntry;
	}

	public StringProperty statusProperty() {
		return status;
	}

	// Getter methods for convenience
	public int getCustomerId() {
		return customerId.get();
	}

	public String getCustomerName() {
		return customerName.get();
	}

	public String getCustomerPhone() {
		return customerPhone.get();
	}

	public double getProductPrice() {
		return productPrice.get();
	}

	public double getInitialPayment() {
		return initialPayment.get();
	}

	public String getComplaint() {
		return complaint.get();
	}

	public LocalDate getDateOfEntry() {
		return dateOfEntry.get();
	}

	public String getStatus() {
		return status.get();
	}
}
