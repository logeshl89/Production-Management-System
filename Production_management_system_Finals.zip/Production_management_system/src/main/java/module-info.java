module com.example.the_course_management_system {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
	requires itextpdf;
	requires org.apache.poi.ooxml;
	requires org.jfree.jfreechart;


    opens com.example.Production_management_system to javafx.fxml;
    exports com.example.Production_management_system;

}
